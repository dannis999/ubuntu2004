/* This file is auto generated, version 140-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#140-Ubuntu SMP Thu Aug 4 02:23:37 UTC 2022"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lcy02-amd64-089"
#define LINUX_COMPILER "gcc version 9.4.0 (Ubuntu 9.4.0-1ubuntu1~20.04.1)"
